#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QTimer>
#include <iostream>
// #include<arpa/inet.h>
// #include<unistd.h>
// #include<sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <vector>

// #include "ckobuki.h"
// #include "rplidar.h"

#include "robot.h"
#include "monteCarlo.h"
#include "mapping.h"
#ifndef DISABLE_MAPPING
#include "mapvisualizer.h"
#endif
#ifndef DISABLE_JOYSTICK
#include <QJoysticks.h>
#endif
namespace Ui {
class MainWindow;
}

/// toto je trieda s oknom.. ktora sa spusti ked sa spusti aplikacia.. su tu
/// vsetky gombiky a spustania...
class MainWindow : public QMainWindow {
  Q_OBJECT

public:
#ifndef DISABLE_OPENCV
  bool useCamera1;
  int actIndex;
  cv::Mat frame[3];
#endif

#ifndef DISABLE_SKELETON
  int updateSkeletonPicture;
  skeleton skeleJoints;
#endif
  explicit MainWindow(QWidget *parent = 0);
  ~MainWindow();

private slots:
 void on_Set_XY_button_clicked();
 void on_Set_XY_button_2_clicked();
 void on_pushButton_9_clicked();

  void on_pushButton_2_clicked();

  void on_pushButton_3_clicked();

  void on_pushButton_6_clicked();

  void on_pushButton_5_clicked();

  void on_pushButton_4_clicked();

  void on_pushButton_clicked();

  void on_pushButton_10_clicked();

  void on_pushButton_11_clicked();

    void on_SET_orig_clicked();
  int paintThisLidar(const std::vector<LaserData> &laserData);
#ifndef DISABLE_OPENCV
  int paintThisCamera(const cv::Mat &cameraData);
#endif
#ifndef DISABLE_SKELETON
  int paintThisSkeleton(const skeleton &skeledata);
#endif
private:
  robot _robot;
  MonteCarlo monteCarlo_;
  //--skuste tu nic nevymazat... pridavajte co chcete, ale pri odoberani by sa
  // mohol stat nejaky drobny problem, co bude vyhadzovat chyby
  #ifndef DISABLE_MAPPING
    Mapping* mapper_;
    MapVisualizer* visualizer_;
  #endif

  Ui::MainWindow *ui;
  void paintEvent(QPaintEvent *event); // Q_DECL_OVERRIDE;
  int updateLaserPicture;
  std::vector<LaserData> copyOfLaserData;
  int datacounter;
  std::string ipaddress;

  QTimer *timer;
#ifndef DISABLE_JOYSTICK
  QJoysticks *instance;
#endif
public slots:
  void setUiValues(double robotX, double robotY, double robotFi, bool obstacle, uint32_t timestamp);
};

#endif // MAINWINDOW_H
